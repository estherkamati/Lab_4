Name: Esther Kamati
Course: WAD621S - Lab 4
Description: Single-page student registration form with dynamic profile cards and summary table.
Instructions: Open index.html in a browser. Fill in the form to add students. Click 'Remove' to delete a student.
Notes: Fully meets Lab 4 requirements. No localStorage or extra pages used.
